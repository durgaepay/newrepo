function BasicAuthHeader()
{
    param([string]$authtoken)

    $ba = (":{0}" -f $authtoken)
    $ba = [System.Text.Encoding]::UTF8.GetBytes($ba)
    $ba = [System.Convert]::ToBase64String($ba)
    $h = @{Authorization=("Basic {0}" -f $ba);ContentType="application/json"}
    return $h
}

$getReleaseUri = "$($env:SYSTEM_COLLECTIONURI)$($env:SYSTEM_TEAMPROJECTID)/_apis/Release/releases/$($env:RELEASE_RELEASEID)?api-version=4.0-preview.4"

$headers = BasicAuthHeader $($env:SYSTEM_ACCESSTOKEN)

$release = Invoke-RestMethod -Uri $getReleaseUri -Headers $headers -Method Get

# Update an existing variable to its value
$release.variables.releaseId.value = "$($env:RELEASE_RELEASEID)";

$release2 = $release | ConvertTo-Json -Depth 100
$release2 = [Text.Encoding]::UTF8.GetBytes($release2)

$content2 = Invoke-RestMethod -Uri $getReleaseUri -Method Put -Headers $headers -ContentType 'application/json' -Body $release2 -Verbose -Debug

$content2 | Write-Host