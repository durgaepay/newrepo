$AppGw = Get-AzApplicationGateway -Name "$($env:AZURE_GATEWAY)" -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)"
$BackendPool = Get-AzApplicationGatewayBackendAddressPool -Name "$($env:AZURE_BACKENDPOOL)" -ApplicationGateway $AppGw
$nic = Get-AzNetworkInterface -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" -Name "$($env:AGENT_NAME)-nic"
$nic.IpConfigurations[0].ApplicationGatewayBackendAddressPools=$BackendPool
Set-AzNetworkInterface -NetworkInterface $nic