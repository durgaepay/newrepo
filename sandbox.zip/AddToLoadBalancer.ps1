$vms = Get-AzVm -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" | Where-Object { $_.Tags['Application'] -eq "$($env:APPLICATIONNAME)" -and $_.Tags['ReleaseId'] -eq "$($env:RELEASE_RELEASEID)" }
foreach($vm in $vms)
{
    $lb = Get-AzLoadBalancer -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" -Name "$($env:AZURE_LOADBALANCER)"
    $BackendPool = Get-AzLoadBalancerBackendAddressPoolConfig -Name "$($env:AZURE_BACKENDPOOL)" -LoadBalancer $lb
    $nic = Get-AzNetworkInterface -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" -Name "$($vm.Name)-nic"
    $nic.IpConfigurations[0].LoadBalancerBackendAddressPools=$BackendPool
    Set-AzNetworkInterface -NetworkInterface $nic
}