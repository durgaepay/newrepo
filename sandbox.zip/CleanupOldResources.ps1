function IsNull($objectToCheck) {
    if ($objectToCheck -eq $null) {
        return $true
    }

    if ($objectToCheck -is [String] -and $objectToCheck -eq [String]::Empty) {
        return $true
    }
    return $false
}

$ResourceGroupName = "$($env:AZURE_RESOURCEGROUP)"
$vms = Get-AzVm -ResourceGroupName $ResourceGroupName | Where-Object { $_.Tags['Application'] -eq "$($env:APPLICATIONNAME)" -and $_.Tags['ReleaseId'] -NE "$($env:RELEASEID)" }

foreach($vm in $vms)
{
	Remove-AzVM -ResourceGroupName $ResourceGroupName -Name "$($vm.Name)" -Force
	$nicName = $vm.NetworkProfile.NetworkInterfaces.Id -split '/' | Select -Last 1
	$nic = Get-AzNetworkInterface -Name $nicName -ResourceGroupName $ResourceGroupName
	$publicIpName = $nic.IpConfigurations.PublicIpAddress.Id -split '/' | Select -Last 1
	$diskName = $vm.StorageProfile.OsDisk.ManagedDisk.Id -split '/' | Select -Last 1

	if (!(IsNull($nicName))) {
		Remove-AzNetworkInterface -Name $nicName -ResourceGroupName $ResourceGroupName -Force
	}
	if (!(IsNull($publicIpName))) {
    	Remove-AzPublicIpAddress -Name $publicIpName -ResourceGroupName $ResourceGroupName -Force
	}
	if (!(IsNull($diskName))) {
		Remove-AzDisk -Name $diskName -ResourceGroupName $ResourceGroupName -Force
	}
}

$nics = Get-AzNetworkInterface -ResourceGroupName $ResourceGroupName |  Where-Object { $_.Tag -NE $null -and  $_.Tag['Application'] -eq "$($env:APPLICATIONNAME)" -and $_.Tag['ReleaseId'] -NE "$($env:RELEASEID)" }

foreach($nic in $nics)
{
   Remove-AzNetworkInterface -Name "$($nic.Name)" -ResourceGroupName $ResourceGroupName -Force
}

$disks = Get-AzDisk -ResourceGroupName $ResourceGroupName |  Where-Object { $_.Tags -NE $null -and  $_.Tags['Application'] -eq "$($env:APPLICATIONNAME)" -and $_.Tags['ReleaseId'] -NE "$($env:RELEASEID)" }

foreach($disk in $disks)
{
   Remove-AzDisk -Name "$($disk.Name)" -ResourceGroupName $ResourceGroupName -Force
}