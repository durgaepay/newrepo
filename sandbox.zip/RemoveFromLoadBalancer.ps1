$vms = Get-AzVm -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" | Where-Object { $_.Tags['Application'] -eq "$($env:APPLICATIONNAME)" -and $_.Tags['ReleaseId'] -NE "$($env:RELEASEID)" }
foreach($vm in $vms)
{
    $nic = Get-AzNetworkInterface -ResourceGroupName "$($env:AZURE_RESOURCEGROUP)" -Name "$($vm.Name)-nic"
    $nic.IpConfigurations[0].LoadBalancerBackendAddressPools.Clear()
    Set-AzNetworkInterface -NetworkInterface $nic
}